<?php

/* default/login.html.twig */
class __TwigTemplate_b1a5138e98ff7a85826d01bf8b45e67044141f6434ffec253bbf7ec55799c0e8 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "default/login.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_e7925b5557bbf7090d5b10491f2efbc384c91bf0e2e35f1644d182902ece9078 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_e7925b5557bbf7090d5b10491f2efbc384c91bf0e2e35f1644d182902ece9078->enter($__internal_e7925b5557bbf7090d5b10491f2efbc384c91bf0e2e35f1644d182902ece9078_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "default/login.html.twig"));

        $__internal_645e008e05b9d0a33ea7602581e218584c09f447174d3cfe78c4430c6cceaa20 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_645e008e05b9d0a33ea7602581e218584c09f447174d3cfe78c4430c6cceaa20->enter($__internal_645e008e05b9d0a33ea7602581e218584c09f447174d3cfe78c4430c6cceaa20_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "default/login.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_e7925b5557bbf7090d5b10491f2efbc384c91bf0e2e35f1644d182902ece9078->leave($__internal_e7925b5557bbf7090d5b10491f2efbc384c91bf0e2e35f1644d182902ece9078_prof);

        
        $__internal_645e008e05b9d0a33ea7602581e218584c09f447174d3cfe78c4430c6cceaa20->leave($__internal_645e008e05b9d0a33ea7602581e218584c09f447174d3cfe78c4430c6cceaa20_prof);

    }

    // line 2
    public function block_title($context, array $blocks = array())
    {
        $__internal_fab732f7727e90fd5287da0d92a6b331afdf6787a51f8559434e828817608baf = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_fab732f7727e90fd5287da0d92a6b331afdf6787a51f8559434e828817608baf->enter($__internal_fab732f7727e90fd5287da0d92a6b331afdf6787a51f8559434e828817608baf_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_b378a24922be937cdb43c6c2a3b9ff57a43c2b7b7bf416bda584fe2b5295cb99 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b378a24922be937cdb43c6c2a3b9ff57a43c2b7b7bf416bda584fe2b5295cb99->enter($__internal_b378a24922be937cdb43c6c2a3b9ff57a43c2b7b7bf416bda584fe2b5295cb99_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        // line 3
        echo "    ";
        $this->displayParentBlock("title", $context, $blocks);
        echo "
    - login
";
        
        $__internal_b378a24922be937cdb43c6c2a3b9ff57a43c2b7b7bf416bda584fe2b5295cb99->leave($__internal_b378a24922be937cdb43c6c2a3b9ff57a43c2b7b7bf416bda584fe2b5295cb99_prof);

        
        $__internal_fab732f7727e90fd5287da0d92a6b331afdf6787a51f8559434e828817608baf->leave($__internal_fab732f7727e90fd5287da0d92a6b331afdf6787a51f8559434e828817608baf_prof);

    }

    // line 6
    public function block_body($context, array $blocks = array())
    {
        $__internal_709ad084e09c7b86f55a6de3c7c2c3ecaed98eccd91025c4d4854c895831e9bc = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_709ad084e09c7b86f55a6de3c7c2c3ecaed98eccd91025c4d4854c895831e9bc->enter($__internal_709ad084e09c7b86f55a6de3c7c2c3ecaed98eccd91025c4d4854c895831e9bc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_73d84fef3fffa0ed19699c4bab2bae6f8b5d507a6c7dfe16067a0b58483abfe1 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_73d84fef3fffa0ed19699c4bab2bae6f8b5d507a6c7dfe16067a0b58483abfe1->enter($__internal_73d84fef3fffa0ed19699c4bab2bae6f8b5d507a6c7dfe16067a0b58483abfe1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 7
        echo "    <div class=\"page\">
        <div class=\"creercompte\">
            <h1>Créer compte</h1>

            <form method=\"post\">
                <input type=\"text\" name=\"name\" placeholder=\"User Name\">
                
                <input type=\"password\" name=\"pass\" placeholder=\"password\">
                
                


                <input type=\"submit\" name=\"signup\" value=\"VALIDER\" class=\"bouton\">
            </form>
        </div>
    ";
        
        $__internal_73d84fef3fffa0ed19699c4bab2bae6f8b5d507a6c7dfe16067a0b58483abfe1->leave($__internal_73d84fef3fffa0ed19699c4bab2bae6f8b5d507a6c7dfe16067a0b58483abfe1_prof);

        
        $__internal_709ad084e09c7b86f55a6de3c7c2c3ecaed98eccd91025c4d4854c895831e9bc->leave($__internal_709ad084e09c7b86f55a6de3c7c2c3ecaed98eccd91025c4d4854c895831e9bc_prof);

    }

    public function getTemplateName()
    {
        return "default/login.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  73 => 7,  64 => 6,  50 => 3,  41 => 2,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}
{% block title %}
    {{parent()}}
    - login
{% endblock %}
{% block body %}
    <div class=\"page\">
        <div class=\"creercompte\">
            <h1>Créer compte</h1>

            <form method=\"post\">
                <input type=\"text\" name=\"name\" placeholder=\"User Name\">
                
                <input type=\"password\" name=\"pass\" placeholder=\"password\">
                
                


                <input type=\"submit\" name=\"signup\" value=\"VALIDER\" class=\"bouton\">
            </form>
        </div>
    {% endblock %}", "default/login.html.twig", "/var/www/html/ChatAjaxSymfony/app/Resources/views/default/login.html.twig");
    }
}
