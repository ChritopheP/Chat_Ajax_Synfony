<?php

/* user/edit.html.twig */
class __TwigTemplate_09fcf7baf6a232da832a734062daceec97231db0a5e830e408ce7753e2fa5681 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "user/edit.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_0741d59a2964f750c2a34e90cd121b52a7e4e847398c970ab39855633e5ca6de = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_0741d59a2964f750c2a34e90cd121b52a7e4e847398c970ab39855633e5ca6de->enter($__internal_0741d59a2964f750c2a34e90cd121b52a7e4e847398c970ab39855633e5ca6de_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "user/edit.html.twig"));

        $__internal_9c846a83111122c8dedb6dd34d94c2d2ed18457284ab0b36cba1f5e86b9cbf42 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9c846a83111122c8dedb6dd34d94c2d2ed18457284ab0b36cba1f5e86b9cbf42->enter($__internal_9c846a83111122c8dedb6dd34d94c2d2ed18457284ab0b36cba1f5e86b9cbf42_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "user/edit.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_0741d59a2964f750c2a34e90cd121b52a7e4e847398c970ab39855633e5ca6de->leave($__internal_0741d59a2964f750c2a34e90cd121b52a7e4e847398c970ab39855633e5ca6de_prof);

        
        $__internal_9c846a83111122c8dedb6dd34d94c2d2ed18457284ab0b36cba1f5e86b9cbf42->leave($__internal_9c846a83111122c8dedb6dd34d94c2d2ed18457284ab0b36cba1f5e86b9cbf42_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_ddf5f7879353e177f895a346a1f07b1b9158ce77ec7502abaf7fe346103d1a8f = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_ddf5f7879353e177f895a346a1f07b1b9158ce77ec7502abaf7fe346103d1a8f->enter($__internal_ddf5f7879353e177f895a346a1f07b1b9158ce77ec7502abaf7fe346103d1a8f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_278cdb846190fd5b0293ddae7c7a23dfd0a1984100db475f98e343e3a4db3582 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_278cdb846190fd5b0293ddae7c7a23dfd0a1984100db475f98e343e3a4db3582->enter($__internal_278cdb846190fd5b0293ddae7c7a23dfd0a1984100db475f98e343e3a4db3582_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "    <h1>User edit</h1>

    ";
        // line 6
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock(($context["edit_form"] ?? $this->getContext($context, "edit_form")), 'form_start');
        echo "
        ";
        // line 7
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(($context["edit_form"] ?? $this->getContext($context, "edit_form")), 'widget');
        echo "
        <input type=\"submit\" value=\"Edit\" />
    ";
        // line 9
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock(($context["edit_form"] ?? $this->getContext($context, "edit_form")), 'form_end');
        echo "

    <ul>
        <li>
            <a href=\"";
        // line 13
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("user_index");
        echo "\">Back to the list</a>
        </li>
        <li>
            ";
        // line 16
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock(($context["delete_form"] ?? $this->getContext($context, "delete_form")), 'form_start');
        echo "
                <input type=\"submit\" value=\"Delete\">
            ";
        // line 18
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock(($context["delete_form"] ?? $this->getContext($context, "delete_form")), 'form_end');
        echo "
        </li>
    </ul>
";
        
        $__internal_278cdb846190fd5b0293ddae7c7a23dfd0a1984100db475f98e343e3a4db3582->leave($__internal_278cdb846190fd5b0293ddae7c7a23dfd0a1984100db475f98e343e3a4db3582_prof);

        
        $__internal_ddf5f7879353e177f895a346a1f07b1b9158ce77ec7502abaf7fe346103d1a8f->leave($__internal_ddf5f7879353e177f895a346a1f07b1b9158ce77ec7502abaf7fe346103d1a8f_prof);

    }

    public function getTemplateName()
    {
        return "user/edit.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  80 => 18,  75 => 16,  69 => 13,  62 => 9,  57 => 7,  53 => 6,  49 => 4,  40 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}

{% block body %}
    <h1>User edit</h1>

    {{ form_start(edit_form) }}
        {{ form_widget(edit_form) }}
        <input type=\"submit\" value=\"Edit\" />
    {{ form_end(edit_form) }}

    <ul>
        <li>
            <a href=\"{{ path('user_index') }}\">Back to the list</a>
        </li>
        <li>
            {{ form_start(delete_form) }}
                <input type=\"submit\" value=\"Delete\">
            {{ form_end(delete_form) }}
        </li>
    </ul>
{% endblock %}
", "user/edit.html.twig", "/var/www/html/ChatAjaxSymfony/app/Resources/views/user/edit.html.twig");
    }
}
