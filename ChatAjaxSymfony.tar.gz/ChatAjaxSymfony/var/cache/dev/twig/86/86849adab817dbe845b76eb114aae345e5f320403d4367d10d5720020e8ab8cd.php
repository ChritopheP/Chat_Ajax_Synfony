<?php

/* user/show.html.twig */
class __TwigTemplate_7712cfcf347dbcdcdb95a530904b78fe0c049a4b9e19499b2731d9594b6368ab extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "user/show.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_f1c27a9159a93dbe2663dce5b22f8b2e1f1c7b5afac0e55669d5dfb47590aed6 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_f1c27a9159a93dbe2663dce5b22f8b2e1f1c7b5afac0e55669d5dfb47590aed6->enter($__internal_f1c27a9159a93dbe2663dce5b22f8b2e1f1c7b5afac0e55669d5dfb47590aed6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "user/show.html.twig"));

        $__internal_8a0cc61cd355bac49234a317f8ec2a7804830a59f07fb66e0ad282efa490b163 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_8a0cc61cd355bac49234a317f8ec2a7804830a59f07fb66e0ad282efa490b163->enter($__internal_8a0cc61cd355bac49234a317f8ec2a7804830a59f07fb66e0ad282efa490b163_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "user/show.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_f1c27a9159a93dbe2663dce5b22f8b2e1f1c7b5afac0e55669d5dfb47590aed6->leave($__internal_f1c27a9159a93dbe2663dce5b22f8b2e1f1c7b5afac0e55669d5dfb47590aed6_prof);

        
        $__internal_8a0cc61cd355bac49234a317f8ec2a7804830a59f07fb66e0ad282efa490b163->leave($__internal_8a0cc61cd355bac49234a317f8ec2a7804830a59f07fb66e0ad282efa490b163_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_d22e73ed68b3697e7bdc8ee1e358da10b55e9567f32ac027c0f46f29b61cbafb = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_d22e73ed68b3697e7bdc8ee1e358da10b55e9567f32ac027c0f46f29b61cbafb->enter($__internal_d22e73ed68b3697e7bdc8ee1e358da10b55e9567f32ac027c0f46f29b61cbafb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_b8723f6f63f6b7906ed1c518fd0fc2815c8e8d52ea67b5a7e321b9c18a376631 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b8723f6f63f6b7906ed1c518fd0fc2815c8e8d52ea67b5a7e321b9c18a376631->enter($__internal_b8723f6f63f6b7906ed1c518fd0fc2815c8e8d52ea67b5a7e321b9c18a376631_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "    <h1>User</h1>

    <table>
        <tbody>
            <tr>
                <th>Id</th>
                <td>";
        // line 10
        echo twig_escape_filter($this->env, $this->getAttribute(($context["user"] ?? $this->getContext($context, "user")), "id", array()), "html", null, true);
        echo "</td>
            </tr>
            <tr>
                <th>Name</th>
                <td>";
        // line 14
        echo twig_escape_filter($this->env, $this->getAttribute(($context["user"] ?? $this->getContext($context, "user")), "name", array()), "html", null, true);
        echo "</td>
            </tr>
            <tr>
                <th>Pass</th>
                <td>";
        // line 18
        echo twig_escape_filter($this->env, $this->getAttribute(($context["user"] ?? $this->getContext($context, "user")), "pass", array()), "html", null, true);
        echo "</td>
            </tr>
        </tbody>
    </table>

    <ul>
        <li>
            <a href=\"";
        // line 25
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("user_index");
        echo "\">Back to the list</a>
        </li>
        <li>
            <a href=\"";
        // line 28
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("user_edit", array("id" => $this->getAttribute(($context["user"] ?? $this->getContext($context, "user")), "id", array()))), "html", null, true);
        echo "\">Edit</a>
        </li>
        <li>
            ";
        // line 31
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock(($context["delete_form"] ?? $this->getContext($context, "delete_form")), 'form_start');
        echo "
                <input type=\"submit\" value=\"Delete\">
            ";
        // line 33
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock(($context["delete_form"] ?? $this->getContext($context, "delete_form")), 'form_end');
        echo "
        </li>
    </ul>
";
        
        $__internal_b8723f6f63f6b7906ed1c518fd0fc2815c8e8d52ea67b5a7e321b9c18a376631->leave($__internal_b8723f6f63f6b7906ed1c518fd0fc2815c8e8d52ea67b5a7e321b9c18a376631_prof);

        
        $__internal_d22e73ed68b3697e7bdc8ee1e358da10b55e9567f32ac027c0f46f29b61cbafb->leave($__internal_d22e73ed68b3697e7bdc8ee1e358da10b55e9567f32ac027c0f46f29b61cbafb_prof);

    }

    public function getTemplateName()
    {
        return "user/show.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  98 => 33,  93 => 31,  87 => 28,  81 => 25,  71 => 18,  64 => 14,  57 => 10,  49 => 4,  40 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}

{% block body %}
    <h1>User</h1>

    <table>
        <tbody>
            <tr>
                <th>Id</th>
                <td>{{ user.id }}</td>
            </tr>
            <tr>
                <th>Name</th>
                <td>{{ user.name }}</td>
            </tr>
            <tr>
                <th>Pass</th>
                <td>{{ user.pass }}</td>
            </tr>
        </tbody>
    </table>

    <ul>
        <li>
            <a href=\"{{ path('user_index') }}\">Back to the list</a>
        </li>
        <li>
            <a href=\"{{ path('user_edit', { 'id': user.id }) }}\">Edit</a>
        </li>
        <li>
            {{ form_start(delete_form) }}
                <input type=\"submit\" value=\"Delete\">
            {{ form_end(delete_form) }}
        </li>
    </ul>
{% endblock %}
", "user/show.html.twig", "/var/www/html/ChatAjaxSymfony/app/Resources/views/user/show.html.twig");
    }
}
