<?php

/* base.html.twig */
class __TwigTemplate_d81bae7d5325a7f23ba92e849144467ab8ed2421c201cbf1d70c17582ad76de7 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_88ed5b8c8f9f900ec107424bea7cdb8917c1e8960668c07c5eefddd04d38fab6 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_88ed5b8c8f9f900ec107424bea7cdb8917c1e8960668c07c5eefddd04d38fab6->enter($__internal_88ed5b8c8f9f900ec107424bea7cdb8917c1e8960668c07c5eefddd04d38fab6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.html.twig"));

        $__internal_74ba19ec46b89cfd3ed29029d6dff5cdec6f030ec99110c1a73a2ded1b0149cb = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_74ba19ec46b89cfd3ed29029d6dff5cdec6f030ec99110c1a73a2ded1b0149cb->enter($__internal_74ba19ec46b89cfd3ed29029d6dff5cdec6f030ec99110c1a73a2ded1b0149cb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html>
    <head>
\t<title>";
        // line 4
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
    </head>
\t
    <body>
        ";
        // line 8
        $this->displayBlock('body', $context, $blocks);
        // line 16
        echo "    </body>
</html>


<html>
<head>
  <title>Login</title>
<meta http-equiv=\"content-type\" content=\"text/html\"; charset=\"utf-8\">

</head>
<body>

<div class=\"connexion\">
<h1>Connexion</h1>



<form method=\"post\" >
<input type=\"text\" name=\"email\" placeholder=\"example@example.com\">
<input type=\"password\" name=\"pass\" placeholder=\"**********\">
<input type=\"submit\"  name=\"signin\" value=\"Connexion\" >
</form>
</div>
</div>
</body>
</html>
";
        
        $__internal_88ed5b8c8f9f900ec107424bea7cdb8917c1e8960668c07c5eefddd04d38fab6->leave($__internal_88ed5b8c8f9f900ec107424bea7cdb8917c1e8960668c07c5eefddd04d38fab6_prof);

        
        $__internal_74ba19ec46b89cfd3ed29029d6dff5cdec6f030ec99110c1a73a2ded1b0149cb->leave($__internal_74ba19ec46b89cfd3ed29029d6dff5cdec6f030ec99110c1a73a2ded1b0149cb_prof);

    }

    // line 4
    public function block_title($context, array $blocks = array())
    {
        $__internal_fd08314ea3f5f47cec48450217069bef63dde2b402c87b2d1364a5548050c82e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_fd08314ea3f5f47cec48450217069bef63dde2b402c87b2d1364a5548050c82e->enter($__internal_fd08314ea3f5f47cec48450217069bef63dde2b402c87b2d1364a5548050c82e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_daf683f7c977761ad3ffacb3f0b9a401fff80ec31c7f2a08ae8f190ee091e222 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_daf683f7c977761ad3ffacb3f0b9a401fff80ec31c7f2a08ae8f190ee091e222->enter($__internal_daf683f7c977761ad3ffacb3f0b9a401fff80ec31c7f2a08ae8f190ee091e222_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Chat";
        
        $__internal_daf683f7c977761ad3ffacb3f0b9a401fff80ec31c7f2a08ae8f190ee091e222->leave($__internal_daf683f7c977761ad3ffacb3f0b9a401fff80ec31c7f2a08ae8f190ee091e222_prof);

        
        $__internal_fd08314ea3f5f47cec48450217069bef63dde2b402c87b2d1364a5548050c82e->leave($__internal_fd08314ea3f5f47cec48450217069bef63dde2b402c87b2d1364a5548050c82e_prof);

    }

    // line 8
    public function block_body($context, array $blocks = array())
    {
        $__internal_a13def9389005a395072596175c8368d1358777c1eb2e7f868b466e07a7bf57f = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_a13def9389005a395072596175c8368d1358777c1eb2e7f868b466e07a7bf57f->enter($__internal_a13def9389005a395072596175c8368d1358777c1eb2e7f868b466e07a7bf57f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_202981821d66498b83d1345501125f945d6f7f2602f935375c3a8a6642d42092 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_202981821d66498b83d1345501125f945d6f7f2602f935375c3a8a6642d42092->enter($__internal_202981821d66498b83d1345501125f945d6f7f2602f935375c3a8a6642d42092_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 9
        echo "
\t<form method=\"POST\" action=\"traitement.php\">
\t    Pseudo : <input type=\"text\" name=\"pseudo\" id=\"pseudo\" /><br />
\t    Message : <textarea name=\"message\" id=\"message\"></textarea><br />
\t    <input type=\"submit\" name=\"submit\" value=\"Envoyez votre message !\" id=\"envoi\" />
\t</form>
        ";
        
        $__internal_202981821d66498b83d1345501125f945d6f7f2602f935375c3a8a6642d42092->leave($__internal_202981821d66498b83d1345501125f945d6f7f2602f935375c3a8a6642d42092_prof);

        
        $__internal_a13def9389005a395072596175c8368d1358777c1eb2e7f868b466e07a7bf57f->leave($__internal_a13def9389005a395072596175c8368d1358777c1eb2e7f868b466e07a7bf57f_prof);

    }

    public function getTemplateName()
    {
        return "base.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  104 => 9,  95 => 8,  77 => 4,  41 => 16,  39 => 8,  32 => 4,  27 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<!DOCTYPE html>
<html>
    <head>
\t<title>{% block title %}Chat{% endblock %}</title>
    </head>
\t
    <body>
        {% block body %}

\t<form method=\"POST\" action=\"traitement.php\">
\t    Pseudo : <input type=\"text\" name=\"pseudo\" id=\"pseudo\" /><br />
\t    Message : <textarea name=\"message\" id=\"message\"></textarea><br />
\t    <input type=\"submit\" name=\"submit\" value=\"Envoyez votre message !\" id=\"envoi\" />
\t</form>
        {% endblock %}
    </body>
</html>


<html>
<head>
  <title>Login</title>
<meta http-equiv=\"content-type\" content=\"text/html\"; charset=\"utf-8\">

</head>
<body>

<div class=\"connexion\">
<h1>Connexion</h1>



<form method=\"post\" >
<input type=\"text\" name=\"email\" placeholder=\"example@example.com\">
<input type=\"password\" name=\"pass\" placeholder=\"**********\">
<input type=\"submit\"  name=\"signin\" value=\"Connexion\" >
</form>
</div>
</div>
</body>
</html>
", "base.html.twig", "/var/www/html/ChatAjaxSymfony/app/Resources/views/base.html.twig");
    }
}
