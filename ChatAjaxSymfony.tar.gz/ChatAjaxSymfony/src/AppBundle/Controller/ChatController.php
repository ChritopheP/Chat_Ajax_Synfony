<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace AppBundle\Controller;

use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;

/**
 * Description of IndexController
 *
 * @author christophe-pereira
 */
class ChatController extends Controller {

    /**
     * 
     * @Route("/login", name="login")
     * @return type
     */
    public function getLogin() {
        return $this->render('default/login.html.twig');
    }

    public function getChat() {
        return $this->render('default/chat.html.twig');
    }

}
